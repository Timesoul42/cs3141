package jensen.zofi.customizablesoundboard;

import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.preference.ListPreference;
import android.preference.Preference;
import android.preference.PreferenceActivity;
import android.support.v7.app.ActionBar;
import android.preference.PreferenceFragment;
import android.preference.PreferenceManager;
import android.preference.RingtonePreference;
import android.support.v7.widget.SwitchCompat;
import android.text.TextUtils;
import android.view.MenuItem;
import android.support.v4.app.NavUtils;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;

public class Settings extends AppCompatActivity {

    SharedPreferences pref;
    Switch switch1;
    boolean stateSwitch1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        Button gotoFrontBtn = (Button) findViewById(R.id.returnToFrontPageBTN );
        gotoFrontBtn.setBackgroundResource(R.color.accent_1);
        gotoFrontBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent startIntent = new Intent( getApplicationContext(), FrontPage.class );
                startActivity(startIntent);

            }
        });

        pref = getSharedPreferences("PREFS", 0);
        stateSwitch1 = pref.getBoolean("switch1", false);

        switch1 = (Switch) findViewById(R.id.switch1);

        switch1.setChecked(stateSwitch1);

        switch1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stateSwitch1 = !stateSwitch1;
                switch1.setChecked(stateSwitch1);
                SharedPreferences.Editor editor = pref.edit();
                editor.putBoolean("switch1", stateSwitch1);
                editor.apply();
            }
        });


    }
}
