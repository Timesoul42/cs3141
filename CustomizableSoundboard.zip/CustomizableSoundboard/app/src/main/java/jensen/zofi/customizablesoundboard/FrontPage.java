package jensen.zofi.customizablesoundboard;

import android.content.ComponentName;
import android.content.Intent;
import android.support.v4.content.IntentCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class FrontPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_front_page);



        Button gotoBoardBtn = (Button) findViewById(R.id.soundBoardBTN );
        gotoBoardBtn.setBackgroundResource(R.color.accent_1);
        gotoBoardBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent startIntent = new Intent( getApplicationContext(), SoundBoardList.class );
                startActivity(startIntent);

            }
        });

        Button settingsBTN = (Button) findViewById(R.id.settingsBTN);
        settingsBTN.setBackgroundResource(R.color.accent_1);
        settingsBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent startIntent = new Intent( getApplicationContext(), Settings.class );
                startActivity(startIntent);

            }
        });

        Button exitBTN = (Button) findViewById(R.id.exitBTN);
        exitBTN.setBackgroundResource(R.color.accent_1);
        exitBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                moveTaskToBack(true); //forces to background
//                android.os.Process.killProcess(android.os.Process.myPid());   // idk what he does
//                System.exit(1); // ends current activity

            }
        });
    }
}
